from django.contrib import admin
from .models import BoardModel
# Register your models here.

admin.site.register(BoardModel)
