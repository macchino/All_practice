from django.contrib import admin
from user.models import Profile
# Register your models here.


admin.site.register(Profile)
