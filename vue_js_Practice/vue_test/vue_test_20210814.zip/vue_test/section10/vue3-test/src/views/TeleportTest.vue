<template>
  <div>
    Teleport
    <ModalButton />
  </div>
</template>

<script>
import ModalButton from '@/components/ModalButton'

export default {
  components:{
    ModalButton
  }
}
</script>

<style>

</style>