<template>
  <div id="app">
    Index<br>
    <a href="index.html">index</a><br>
    <a href="users.html">users</a>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>